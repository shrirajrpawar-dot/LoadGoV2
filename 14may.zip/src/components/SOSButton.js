import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Alert, Modal, Linking,
  ScrollView, ActivityIndicator, SafeAreaView, Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { doc, updateDoc, addDoc, collection, serverTimestamp, getDoc } from 'firebase/firestore';
import { db } from '../../../firebase';
import { useAuth } from '../../contexts/AuthContext';

const { height } = Dimensions.get('window');

export function SOSButton({ booking, position }) {
  const { user, profile } = useAuth();
  const [sosVisible, setSosVisible] = useState(false);
  const [sosActive, setSosActive] = useState(false);
  const [sosLoading, setSosLoading] = useState(false);

  const triggerSOS = async (type) => {
    setSosLoading(true);
    try {
      // Add SOS record to Firestore
      const sosRef = await addDoc(collection(db, 'sos'), {
        customerId: user.uid,
        customerName: profile?.name || 'Unknown',
        customerPhone: profile?.phone || '',
        type, // 'driver', 'support', 'police'
        bookingId: booking?.id || null,
        pickupLocation: booking?.pickup || {},
        dropLocation: booking?.drop || {},
        customerLocation: position || {},
        triggeredAt: serverTimestamp(),
        status: 'active',
        notes: '',
      });

      // If booking exists, alert driver
      if (booking?.id && type === 'driver') {
        await updateDoc(doc(db, 'bookings', booking.id), {
          sosTriggered: true,
          sosTriggeredAt: serverTimestamp(),
          sosTriggeredBy: 'customer',
        });
      }

      // If support, also notify support
      if (type === 'support') {
        // Admin notification would be in cloud function
      }

      setSosActive(true);
      setSosVisible(false);

      Alert.alert(
        '🚨 SOS Activated',
        type === 'driver'
          ? '✓ Driver has been alerted. Support team is being notified.'
          : type === 'support'
            ? '✓ Support team has been notified. They will call you shortly.'
            : '✓ Emergency services have been contacted. Stay safe.',
        [{ text: 'OK' }]
      );

      // Auto-deactivate after 30 minutes
      setTimeout(() => {
        setSosActive(false);
      }, 30 * 60 * 1000);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setSosLoading(false);
    }
  };

  const cancelSOS = async () => {
    if (!sosActive) return;
    try {
      // Find active SOS and mark as cancelled
      // In production, use a query to find the active SOS
      setSosActive(false);
      Alert.alert('SOS Cancelled', 'Your emergency alert has been deactivated.');
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  };

  return (
    <>
      {/* SOS Button */}
      <TouchableOpacity
        style={[s.sosButton, sosActive && s.sosButtonActive]}
        onPress={() => setSosVisible(true)}
        disabled={sosLoading}
      >
        {sosLoading ? (
          <ActivityIndicator color="#FFFFFF" size="large" />
        ) : (
          <>
            <Ionicons
              name={sosActive ? 'alert-circle' : 'warning'}
              size={32}
              color="#FFFFFF"
            />
            <Text style={s.sosButtonText}>{sosActive ? 'SOS ACTIVE' : 'SOS'}</Text>
          </>
        )}
      </TouchableOpacity>

      {/* SOS Modal */}
      <Modal
        visible={sosVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setSosVisible(false)}
      >
        <View style={s.overlay}>
          <View style={s.sosModal}>
            <View style={s.sosHeader}>
              <Ionicons name="alert-circle" size={28} color="#DC2626" />
              <Text style={s.sosTitle}>Emergency Help</Text>
              <TouchableOpacity
                onPress={() => setSosVisible(false)}
                style={s.closeBtn}
              >
                <Ionicons name="close" size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <Text style={s.sosSubtitle}>
              Choose who you want to contact:
            </Text>

            <ScrollView style={s.sosOptions} showsVerticalScrollIndicator={false}>
              {/* Contact Driver */}
              <TouchableOpacity
                style={s.sosOption}
                onPress={() => triggerSOS('driver')}
                disabled={sosLoading}
              >
                <View style={s.sosOptionIcon}>
                  <Ionicons name="car" size={24} color="#10B981" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.sosOptionTitle}>Alert Driver</Text>
                  <Text style={s.sosOptionDesc}>
                    Your driver will be immediately notified of your emergency
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#D1D5DB" />
              </TouchableOpacity>

              {/* Contact Support */}
              <TouchableOpacity
                style={s.sosOption}
                onPress={() => triggerSOS('support')}
                disabled={sosLoading}
              >
                <View style={s.sosOptionIcon}>
                  <Ionicons name="headset" size={24} color="#3B82F6" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.sosOptionTitle}>Contact Support</Text>
                  <Text style={s.sosOptionDesc}>
                    Sarthi support team will call you within 2 minutes
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#D1D5DB" />
              </TouchableOpacity>

              {/* Call Police */}
              <TouchableOpacity
                style={s.sosOption}
                onPress={() => {
                  Alert.alert(
                    'Call Police?',
                    'This will call emergency services (100 in India)',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      {
                        text: 'Call Now',
                        onPress: () => {
                          triggerSOS('police');
                          Linking.openURL('tel:100');
                        },
                      },
                    ]
                  );
                }}
                disabled={sosLoading}
              >
                <View style={s.sosOptionIcon}>
                  <Ionicons name="shield" size={24} color="#DC2626" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.sosOptionTitle}>Call Police</Text>
                  <Text style={s.sosOptionDesc}>
                    Will call emergency services (100) and notify Sarthi
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#D1D5DB" />
              </TouchableOpacity>

              {/* Share Live Location */}
              <TouchableOpacity
                style={s.sosOption}
                onPress={() => {
                  Alert.alert(
                    'Share Live Location',
                    'Share your live location with support team for 30 minutes?',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      {
                        text: 'Share',
                        onPress: () => {
                          // Start live location sharing
                          setSosVisible(false);
                        },
                      },
                    ]
                  );
                }}
              >
                <View style={s.sosOptionIcon}>
                  <Ionicons name="location" size={24} color="#F59E0B" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.sosOptionTitle}>Share Live Location</Text>
                  <Text style={s.sosOptionDesc}>
                    Real-time location shared with Sarthi support team
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#D1D5DB" />
              </TouchableOpacity>
            </ScrollView>

            <View style={s.sosFooter}>
              <Text style={s.sosFooterText}>
                ℹ️ Your location and booking details will be shared with the appropriate contacts
              </Text>
              <TouchableOpacity
                style={s.cancelBtn}
                onPress={() => setSosVisible(false)}
              >
                <Text style={s.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* SOS Active Banner */}
      {sosActive && (
        <View style={s.sosActiveBanner}>
          <Ionicons name="alert-circle" size={20} color="#FFFFFF" />
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={s.sosActiveBannerTitle}>🚨 SOS Active</Text>
            <Text style={s.sosActiveBannerText}>
              Support team is monitoring your journey
            </Text>
          </View>
          <TouchableOpacity onPress={cancelSOS}>
            <Text style={s.sosActiveBannerCancel}>Cancel</Text>
          </TouchableOpacity>
        </View>
      )}
    </>
  );
}

const s = StyleSheet.create({
  sosButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#DC2626',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#DC2626',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  sosButtonActive: {
    backgroundColor: '#991B1B',
    shadowOpacity: 0.5,
  },
  sosButtonText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '900',
    marginTop: 4,
  },

  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  sosModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: height * 0.85,
    paddingTop: 16,
  },

  sosHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  sosTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#111827',
    marginLeft: 12,
    flex: 1,
  },
  closeBtn: {
    padding: 8,
    marginRight: -8,
  },

  sosSubtitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },

  sosOptions: {
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  sosOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 12,
    marginBottom: 8,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  sosOptionIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  sosOptionTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: '#111827',
    marginBottom: 2,
  },
  sosOptionDesc: {
    fontSize: 12,
    color: '#6B7280',
    lineHeight: 16,
  },

  sosFooter: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  sosFooterText: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
    marginBottom: 12,
    lineHeight: 16,
  },
  cancelBtn: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#F3F4F6',
    borderRadius: 10,
    alignItems: 'center',
  },
  cancelBtnText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#6B7280',
  },

  sosActiveBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DC2626',
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 10,
    marginHorizontal: 16,
    marginVertical: 8,
  },
  sosActiveBannerTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  sosActiveBannerText: {
    fontSize: 11,
    color: '#FEE2E2',
  },
  sosActiveBannerCancel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFFFFF',
    textDecorationLine: 'underline',
  },
});