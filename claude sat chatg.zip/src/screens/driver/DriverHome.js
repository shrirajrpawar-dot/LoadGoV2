import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Alert, ActivityIndicator, Switch, ScrollView, TextInput, Linking, Animated, Platform, Dimensions,
  KeyboardAvoidingView
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import {
  collection, query, where, onSnapshot,
  doc, updateDoc, getDoc, serverTimestamp, arrayUnion, addDoc,
} from 'firebase/firestore';
import { db } from '../../../firebase';
import { useAuth } from '../../contexts/AuthContext';

const { width, height } = Dimensions.get('window');

const VLABELS = {
  bike: '🏍️ Bike', 
  '3wheeler': '🛺 3 Wheeler Rickshaw',
  '3wheeler_transport': '🛺 3 Wheeler Transport',
  chota_hatti: '🚛 Chota Hatti', 
  tempo: '🚚 Tempo',
  sedan: '🚗 Sedan',
  hatchback: '🚙 Hatchback',
  '7_seater': '🚐 7 Seater'
};

export default function DriverHome() {
  const { user, driverDoc } = useAuth();
  const mapRef = useRef(null);
  
  const [isOnline, setIsOnline] = useState(false);
  const [allSearching, setAllSearching] = useState([]);
  const [myBookings, setMyBookings] = useState([]);
  const [otpInput, setOtpInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [focusedIndex, setFocusedIndex] = useState(0);

  // KYC status check
  const kycStatus = driverDoc?.kyc?.status || 'not_started';
  const isKycApproved = kycStatus === 'approved';

  const currentBooking = myBookings.find(b => 
    ['accepted', 'arrived', 'picked_up', 'reached_dropoff'].includes(b.status)
  ) || null;

  const availableBookings = allSearching.filter(b => 
    b.vehicleType === driverDoc?.vehicle?.type && 
    !(b.rejectedByDrivers || []).includes(user?.uid)
  );

  useEffect(() => {
    if (!user?.uid) return;

    const unsubDriver = onSnapshot(doc(db, 'drivers', user.uid), snap => {
      if (snap.exists()) setIsOnline(snap.data().status === 'online');
    });

    const unsubSearching = onSnapshot(query(collection(db, 'bookings'), where('status', '==', 'searching')), snap => {
      setAllSearching(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });

    const unsubMine = onSnapshot(query(collection(db, 'bookings'), where('driverId', '==', user.uid)), snap => {
      setMyBookings(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => { unsubDriver(); unsubSearching(); unsubMine(); };
  }, [user?.uid]);

  useEffect(() => {
    const target = currentBooking || availableBookings[focusedIndex];
    if (target?.pickup?.lat && target?.drop?.lat && mapRef.current) {
      setTimeout(() => {
        mapRef.current?.fitToCoordinates([
          { latitude: target.pickup.lat, longitude: target.pickup.lng },
          { latitude: target.drop.lat, longitude: target.drop.lng }
        ], { edgePadding: { top: 100, right: 60, bottom: height * 0.45, left: 60 }, animated: true });
      }, 600);
    }
  }, [currentBooking?.status, focusedIndex, availableBookings.length]);

  // Logic to prevent going online
  const toggleOnline = async () => {
    if (!isKycApproved) {
      Alert.alert(
        "🔒 KYC Required",
        "Your account is not yet verified. Please complete your KYC and wait for admin approval to start receiving bookings.",
        [{ text: "View KYC Status", onPress: () => {} }] // Add navigation to Profile if needed
      );
      return;
    }

    try {
      await updateDoc(doc(db, 'drivers', user.uid), { 
        status: isOnline ? 'offline' : 'online' 
      });
    } catch (e) { 
      Alert.alert("Error", "Could not change status"); 
    }
  };

  const updateBookingStatus = async (s) => {
    if (!currentBooking?.id) return;
    setActionLoading(true);
    try {
      await updateDoc(doc(db, 'bookings', currentBooking.id), { status: s });
    } catch (e) {
      Alert.alert("Error", "Could not update status");
    }
    setActionLoading(false);
  };

  const verifyOtp = async (type) => {
    if (!currentBooking) return;
    const correct = type === 'pickup' ? currentBooking.pickupOtp : currentBooking.deliveryOtp;
    if (otpInput !== correct) return Alert.alert("Wrong OTP", "Please ask the customer for the correct code.");
    
    setActionLoading(true);
    try {
      if (type === 'pickup') {
        await updateDoc(doc(db, 'bookings', currentBooking.id), { status: 'picked_up' });
      } else {
        await updateDoc(doc(db, 'bookings', currentBooking.id), { status: 'completed' });
        Alert.alert("Job Done!", "Payment info updated in your earnings.");
      }
      setOtpInput('');
    } catch (e) {
      Alert.alert("Error", "Verification failed");
    }
    setActionLoading(false);
  };

  const handleCall = (phone) => {
    if (!phone) return Alert.alert("Error", "Customer phone number not found.");
    Linking.openURL(`tel:${phone}`);
  };

  if (loading || !user) return <View style={s.center}><ActivityIndicator size="large" color="#000" /></View>;

  return (
    <View style={s.container}>
      <MapView 
        ref={mapRef} 
        provider={PROVIDER_GOOGLE} 
        style={s.map} 
        showsUserLocation={true} 
        initialRegion={{ latitude: 19.076, longitude: 72.8777, latitudeDelta: 0.05, longitudeDelta: 0.05 }}
      >
         {currentBooking?.pickup && (
           <>
            <Marker coordinate={{latitude: currentBooking.pickup.lat, longitude: currentBooking.pickup.lng}} title="Pickup" />
            <Marker coordinate={{latitude: currentBooking.drop.lat, longitude: currentBooking.drop.lng}} pinColor="blue" title="Dropoff" />
           </>
         )}
      </MapView>

      <SafeAreaView style={s.header} pointerEvents="box-none">
        <View style={s.headerBox}>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={s.title}>Driver Mode</Text>
                {!isKycApproved && <Ionicons name="lock-closed" size={16} color="#F59E0B" style={{ marginLeft: 6 }} />}
            </View>
            <Text style={{ fontSize: 12, color: !isKycApproved ? '#F59E0B' : (isOnline ? 'green' : 'red'), fontWeight: '600' }}>
              {!isKycApproved ? `KYC ${kycStatus.toUpperCase()}` : (isOnline ? 'ONLINE' : 'OFFLINE')}
            </Text>
          </View>
          <Switch 
            value={isOnline} 
            onValueChange={toggleOnline}
            trackColor={{ false: "#D1D5DB", true: "#10B981" }}
          />
        </View>
      </SafeAreaView>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.bottom}>
        {currentBooking ? (
          <View style={s.panel}>
            <Text style={s.statusTxt}>{currentBooking.status?.replace('_', ' ').toUpperCase()}</Text>
            <View style={s.customerBox}>
               <Text style={s.name}>{currentBooking.customerName || 'Customer'}</Text>
               <TouchableOpacity onPress={() => handleCall(currentBooking.customerPhone)}>
                 <Ionicons name="call" size={28} color="green" />
               </TouchableOpacity>
            </View>
            <ScrollView style={{maxHeight: 100}} showsVerticalScrollIndicator={false}>
               <Text style={s.addressText}>📍 {currentBooking.pickup?.address}</Text>
               <Text style={s.addressText}>🏁 {currentBooking.drop?.address}</Text>
            </ScrollView>
            
            {['accepted', 'picked_up'].includes(currentBooking.status) ? (
              <TouchableOpacity style={s.btn} onPress={() => updateBookingStatus(currentBooking.status === 'accepted' ? 'arrived' : 'reached_dropoff')}>
                <Text style={s.btnTxt}>I HAVE ARRIVED</Text>
              </TouchableOpacity>
            ) : (
              <View>
                <TextInput style={s.input} value={otpInput} onChangeText={setOtpInput} placeholder="Enter 4-digit OTP" keyboardType="numeric" maxLength={4} />
                <TouchableOpacity style={s.btn} onPress={() => verifyOtp(currentBooking.status === 'arrived' ? 'pickup' : 'delivery')}>
                  {actionLoading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnTxt}>VERIFY OTP</Text>}
                </TouchableOpacity>
              </View>
            )}

            {['accepted', 'arrived'].includes(currentBooking.status) && (
              <TouchableOpacity style={s.cancel} onPress={() => updateDoc(doc(db, 'bookings', currentBooking.id), { status: 'cancelled' })}>
                <Text style={{color: 'red', fontWeight: 'bold'}}>Cancel Trip</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          isOnline && availableBookings.length > 0 ? (
            <FlatList 
              data={availableBookings} 
              horizontal 
              pagingEnabled 
              showsHorizontalScrollIndicator={false}
              onScroll={e => setFocusedIndex(Math.round(e.nativeEvent.contentOffset.x / width))} 
              renderItem={({item}) => (
                <View style={s.card}>
                  <Text style={s.price}>₹{Math.round((item.fare?.totalInPaise || 0)/100)}</Text>
                  <Text style={s.reqTitle}>{VLABELS[item.vehicleType] || 'Delivery Request'}</Text>
                  <Text style={{color: '#666', marginBottom: 10}}>Customer: {item.customerName}</Text>
                  <TouchableOpacity style={s.btn} onPress={() => updateDoc(doc(db, 'bookings', item.id), { status: 'accepted', driverId: user.uid })}>
                    <Text style={s.btnTxt}>ACCEPT BOOKING</Text>
                  </TouchableOpacity>
                </View>
            )} />
          ) : (
            <View style={s.panel}>
                <Text style={s.centerTxt}>
                    {!isKycApproved 
                        ? "Complete KYC to see requests" 
                        : (isOnline ? "Searching for requests nearby..." : "You are currently Offline")}
                </Text>
            </View>
          )
        )}
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#eee' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  map: { width: width, height: height, position: 'absolute' },
  header: { position: 'absolute', top: 0, width: '100%', padding: 10 },
  headerBox: { backgroundColor: '#fff', padding: 15, borderRadius: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', elevation: 5, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 10 },
  title: { fontSize: 18, fontWeight: 'bold' },
  bottom: { position: 'absolute', bottom: 0, width: '100%' },
  panel: { backgroundColor: '#fff', padding: 20, borderTopLeftRadius: 24, borderTopRightRadius: 24, elevation: 10, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 15 },
  customerBox: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 15 },
  name: { fontSize: 20, fontWeight: 'bold' },
  statusTxt: { color: 'green', fontWeight: 'bold', letterSpacing: 1 },
  addressText: { fontSize: 14, color: '#444', marginBottom: 8 },
  btn: { backgroundColor: '#000', padding: 18, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  btnTxt: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  input: { borderBottomWidth: 2, borderColor: '#eee', padding: 10, textAlign: 'center', fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  card: { width: width - 40, margin: 20, backgroundColor: '#fff', padding: 25, borderRadius: 24, elevation: 5, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 10 },
  price: { fontSize: 28, fontWeight: 'bold', color: 'green' },
  reqTitle: { fontSize: 16, fontWeight: 'bold', marginVertical: 5 },
  cancel: { marginTop: 20, alignItems: 'center', padding: 10 },
  centerTxt: { textAlign: 'center', fontSize: 16, color: '#666', fontWeight: '500' }
});